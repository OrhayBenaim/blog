---
name: image-optimizer
description: Optimize images for web by converting to WebP format using Squoosh CLI. This skill should be used when working with images in a web application, before committing changes. Triggers on image-related work in web projects, adding images to web apps, or when image files (PNG, JPG, JPEG, GIF, BMP, TIFF, SVG) are present in staged or modified files.
---

# Image Optimizer

Optimize images for web delivery by converting them to WebP format using the Squoosh CLI (`@nicolo-ribaudo/squoosh-cli`).

## When to Use

- Before committing changes that include image files in a web project
- When new images (PNG, JPG, JPEG, GIF, BMP, TIFF) are added to a web app
- When optimizing existing images that lack WebP variants

## Workflow

### 1. Detect Unoptimized Images

Scan the project for image files that do not have a corresponding `.webp` file next to them. Target extensions: `.png`, `.jpg`, `.jpeg`, `.gif`, `.bmp`, `.tiff`.

To find unoptimized images, run the bundled script:

```bash
python "<skill_dir>/scripts/find_unoptimized.py" <project_root>
```

This script outputs a list of image files that are missing a `.webp` sibling.

### 2. Convert to WebP

Use the Squoosh CLI to convert each unoptimized image to WebP format. Install if not available:

```bash
npx @nicolo-ribaudo/squoosh-cli --webp auto <image_path>
```

If `npx` fails or the package is unavailable, fall back to `@frostoven/squoosh-cli`:

```bash
npx @frostoven/squoosh-cli --webp auto <image_path>
```

The `auto` preset uses sensible defaults (lossy, quality ~75). The output `.webp` file is saved in the same directory as the original.

To convert multiple files at once, pass them all as arguments:

```bash
npx @nicolo-ribaudo/squoosh-cli --webp auto image1.png image2.jpg image3.gif
```

### 3. Update Source References

After converting, update any source code references (HTML `<img>`, CSS `background-image`, JS/TS imports) to use the new `.webp` files. Consider using `<picture>` elements with fallbacks:

```html
<picture>
  <source srcset="image.webp" type="image/webp">
  <img src="image.png" alt="description">
</picture>
```

### 4. Verify

- Confirm each original image has a `.webp` sibling
- Confirm source code references are updated
- Stage the new `.webp` files for commit

## Notes

- Original files are preserved (not deleted) for fallback compatibility
- The `.webp` file is saved next to the original with the same base name
- SVG files are excluded from conversion (already optimized for web as vector format)
- For bulk operations, the `find_unoptimized.py` script can be piped directly to the CLI
