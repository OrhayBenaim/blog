#!/usr/bin/env python3
"""Find image files in a project that are missing a .webp optimized variant.

Usage:
    python find_unoptimized.py <project_root> [--extensions png,jpg,jpeg,gif,bmp,tiff]

Outputs one file path per line for each image that does not have a corresponding
.webp file in the same directory.
"""

import argparse
import sys
from pathlib import Path

DEFAULT_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "bmp", "tiff"}

SKIP_DIRS = {
    "node_modules", ".git", ".next", "dist", "build", ".cache",
    "__pycache__", ".venv", "venv", ".svn", ".hg",
}


def find_unoptimized(root: Path, extensions: set[str]) -> list[Path]:
    unoptimized = []
    for path in root.rglob("*"):
        if any(part in SKIP_DIRS for part in path.parts):
            continue
        if path.suffix.lstrip(".").lower() in extensions:
            webp_sibling = path.with_suffix(".webp")
            if not webp_sibling.exists():
                unoptimized.append(path)
    return sorted(unoptimized)


def main():
    parser = argparse.ArgumentParser(description="Find images missing WebP variants")
    parser.add_argument("root", type=Path, help="Project root directory to scan")
    parser.add_argument(
        "--extensions", "-e",
        default=",".join(DEFAULT_EXTENSIONS),
        help=f"Comma-separated image extensions (default: {','.join(DEFAULT_EXTENSIONS)})",
    )
    args = parser.parse_args()

    if not args.root.is_dir():
        print(f"Error: {args.root} is not a directory", file=sys.stderr)
        sys.exit(1)

    extensions = {ext.strip().lower() for ext in args.extensions.split(",")}
    results = find_unoptimized(args.root, extensions)

    if not results:
        print("All images have WebP variants.", file=sys.stderr)
        sys.exit(0)

    for path in results:
        print(path)

    print(f"\nFound {len(results)} image(s) without WebP variants.", file=sys.stderr)


if __name__ == "__main__":
    main()
